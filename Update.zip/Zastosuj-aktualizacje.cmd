@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Zastosuj-aktualizacje.ps1"
pause
