﻿$ErrorActionPreference='Stop'
$data=Join-Path $env:USERPROFILE 'AppData\LocalLow\Epic-Secure_cloud\EpicSecure'
if(-not(Test-Path -LiteralPath $data)){$data=Join-Path $env:USERPROFILE 'AppData\LocalLow\Epic-Secure.cloud\EpicSecure'}
$policy=Join-Path $data 'launcher-policy.cache.json'
$package=Get-ChildItem -LiteralPath (Join-Path $data 'updates') -Filter '*.zip' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if(-not $package){throw 'Najpierw pobierz aktualizację w Launcherze.'}
& (Join-Path $PSScriptRoot 'Install-Update.ps1') -Package $package.FullName -Target launcher -LauncherRoot $PSScriptRoot -PolicyPath $policy -ResultPath (Join-Path $data 'update-result.json') -Restart
