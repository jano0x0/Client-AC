param([Parameter(Mandatory=$true)][string]$Launcher,[int]$ParentId,[long]$ParentStarted,[Parameter(Mandatory=$true)][string]$StopFile)
$ErrorActionPreference='Stop'
$Launcher=[IO.Path]::GetFullPath($Launcher)
$StopFile=[IO.Path]::GetFullPath($StopFile)
if(-not [IO.File]::Exists($Launcher) -or [IO.Path]::GetExtension($Launcher) -ne '.exe' -or [IO.Path]::GetExtension($StopFile) -ne '.stop'){exit 1}
$restarts=New-Object 'Collections.Generic.List[datetime]'
$beat=$StopFile+'.beat'
while(-not [IO.File]::Exists($StopFile)){
 Start-Sleep -Seconds 3
 $parent=Get-Process -Id $ParentId -ErrorAction SilentlyContinue
 $alive=$false
 if($parent){try{$alive=$parent.StartTime.ToUniversalTime().Ticks -eq $ParentStarted}catch{$alive=$true}}
 $responding=$true
 if($alive){try{$responding=$parent.Responding}catch{}}
 if($parent){$parent.Dispose()}
 if($alive){
  # Restart a hung window only after its main-loop heartbeat has also stopped.
  if([IO.File]::Exists($beat) -and -not $responding -and ([datetime]::UtcNow-[IO.File]::GetLastWriteTimeUtc($beat)).TotalSeconds -gt 90){
   if([IO.File]::Exists($StopFile)){break}
   Stop-Process -Id $ParentId -Force -ErrorAction SilentlyContinue
  }else{continue}
 }
 if([IO.File]::Exists($StopFile)){break}
 $now=[datetime]::UtcNow
 for($i=$restarts.Count-1;$i -ge 0;$i--){if(($now-$restarts[$i]).TotalMinutes -ge 10){$restarts.RemoveAt($i)}}
 if($restarts.Count -ge 3){break}
 $restarts.Add($now)
 Start-Sleep -Seconds 2
 if([IO.File]::Exists($StopFile)){break}
 $child=Start-Process -FilePath $Launcher -ArgumentList @('-start-in-tray','-launcher-recovery-stop',('"'+$StopFile+'"')) -WorkingDirectory ([IO.Path]::GetDirectoryName($Launcher)) -WindowStyle Hidden -PassThru
 $ParentId=$child.Id;$ParentStarted=$child.StartTime.ToUniversalTime().Ticks
 $child.Dispose()
}
