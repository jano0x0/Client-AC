﻿param([Parameter(Mandatory=$true)][string]$Package,[string]$Target='launcher',[int]$WaitForPid=0,[switch]$Restart,[string]$LauncherRoot=$PSScriptRoot,[Parameter(Mandatory=$true)][string]$PolicyPath,[string]$ResultPath)
$ErrorActionPreference='Stop'
$TrustedKey='<RSAKeyValue><Modulus>1oL6pei8oZ5P5+GoKoxLu+4ncLwANV9qiEQ69nOaEh1HALcW16eDa05JiP4tVMoZEKoNRsxiSaeACHlSXbKbl2dL05lRtJNUMbaj0N/lP9SWWL+V8V+Wx5A8792Q55MBdL/OxppoTBmeJIbTkC4B1Y1gJiGWu3z5XQ9RewMKo2weFSqJLyyc/9A0jy5mroUTSWqsGTehz0FkDSBB2wRE0v7LPtU8tZ39qDUkJoRQAL/wMkZKqIWdsCQ3jVsBmgn1WAIB/1aDXzwgsUERAlhAJbxZQfs5TO3+tyBbkPj+b7Nv+NueH5Gg/uxDJ1lfEPc/CFFdQwF5rkF05abyNaprMC4v911PXJMiP3mGt8URScroqjfXtnpZdf+gcpaq2buaH8wdBtK7wDsQej7Jhw/HHa+c5npZpLELbyNv39EOOAtun0fbb1CxELQ7xtwW24byxSJKfGlCGXm/qIQ0ARYH4haFLkrMqiXnwfx2VF1zbMByBUeW8CGy4xr4CuoBPivF</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
$launcherRoot=[IO.Path]::GetFullPath($LauncherRoot).TrimEnd('\')
$result=if($ResultPath){$ResultPath}else{Join-Path (Split-Path $PolicyPath) 'update-result.json'}
$journal=[Collections.Generic.List[object]]::new()
$logPath=$result+'.log'
$staging=$null;$backup=$null;$success=$false
function Log([string]$text){try{[IO.File]::AppendAllText($logPath,([DateTime]::UtcNow.ToString('o')+' '+$text+[Environment]::NewLine),[Text.UTF8Encoding]::new($false))}catch{}}
function SafeChild([string]$root,[string]$relative){
 if([IO.Path]::IsPathRooted($relative)-or $relative.Contains(':')-or ($relative.Replace('/','\').Split('\')-contains '..')){throw 'Nieprawidłowa ścieżka pakietu.'}
 $path=[IO.Path]::GetFullPath((Join-Path $root $relative));if(-not $path.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Ścieżka poza katalogiem aktualizacji.'};return $path
}
function RejectParentLinks([string]$path){for($directory=[IO.DirectoryInfo]::new($path);$directory;$directory=$directory.Parent){if($directory.Exists-and ($directory.Attributes-band [IO.FileAttributes]::ReparsePoint)){throw 'Dowiązanie w ścieżce instalacji.'}}}
function EnsureSpace([string]$path,[long]$bytes){$drive=[IO.DriveInfo]::new([IO.Path]::GetPathRoot($path));if($drive.IsReady-and $drive.AvailableFreeSpace-lt $bytes){throw ('Brak wolnego miejsca: potrzeba '+[Math]::Ceiling($bytes/1MB)+' MB.')}}
try{
 if($Target-ne 'launcher'){throw 'Ten instalator obsługuje wyłącznie Launcher.'}
 RejectParentLinks $launcherRoot
 if($WaitForPid-gt 0-and (Get-Process -Id $WaitForPid -ErrorAction SilentlyContinue)){Wait-Process -Id $WaitForPid -Timeout 120}
 if(Get-Process EpicSecure -ErrorAction SilentlyContinue|Where-Object {$_.Path-eq (Join-Path $launcherRoot 'EpicSecure.exe')}){throw 'Launcher nadal działa.'}
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $config=Get-Content -Raw -LiteralPath (Join-Path $launcherRoot 'EpicSecure_Data\StreamingAssets\launcher-control.json')|ConvertFrom-Json
 if($config.public_key_xml-ne $TrustedKey){throw 'Niezgodny zaufany klucz instalatora.'}
 $envelope=Get-Content -Raw -LiteralPath $PolicyPath|ConvertFrom-Json;$payload=[Convert]::FromBase64String($envelope.payload)
 $rsa=[Security.Cryptography.RSACryptoServiceProvider]::new();$rsa.FromXmlString($TrustedKey)
 try{if(-not $rsa.VerifyData($payload,[Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'),[Convert]::FromBase64String($envelope.signature))){throw 'Nieprawidłowy podpis polityki.'}}finally{$rsa.Dispose()}
 $policy=[Text.Encoding]::UTF8.GetString($payload)|ConvertFrom-Json
 $age=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()-[long]$policy.issued
 if($age-lt -300-or $age-gt ([long]$policy.offline_max_days*86400)){throw 'Podpisana polityka wygasła.'}
 $hasher=[Security.Cryptography.SHA256]::Create();$stream=[IO.File]::OpenRead($Package)
 try{$sha=([BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$hasher.Dispose()}
 $release=@($policy.releases|Where-Object {$_.target-eq 'launcher'-and $_.sha256-eq $sha})|Select-Object -First 1
 if(-not $release){throw 'Paczka nie odpowiada podpisanej publikacji Launchera.'}
 if([long]$release.size-gt 0-and (Get-Item -LiteralPath $Package).Length-ne [long]$release.size){throw 'Nieprawidłowy rozmiar paczki.'}
 $stamp=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff');$staging=Join-Path $launcherRoot ('UpdateStaging\'+[guid]::NewGuid().ToString('N'));$backup=Join-Path $launcherRoot ('IntegrationBackups\update-'+$stamp)
 New-Item -ItemType Directory -Path $staging,$backup -Force|Out-Null
 RejectParentLinks $staging;RejectParentLinks $backup
 $probe=Join-Path $launcherRoot ('.update-write-'+[guid]::NewGuid().ToString('N'));[IO.File]::WriteAllText($probe,'probe');Remove-Item -LiteralPath $probe
 $archive=[IO.Compression.ZipFile]::OpenRead((Resolve-Path -LiteralPath $Package))
 try{
  if($archive.Entries.Count-gt 100000){throw 'Zbyt wiele plików w paczce.'}
  [long]$required=64MB;$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  foreach($entry in $archive.Entries){$file=SafeChild $staging $entry.FullName;if(-not $seen.Add($file)){throw 'Powtórzona ścieżka w ZIP.'};if($entry.FullName.Replace('\','/')-match '(^|/)Games/'){throw 'Paczka Launchera nie może nadpisywać gier.'};$required+=$entry.Length;$targetFile=SafeChild $launcherRoot $entry.FullName;if(Test-Path -LiteralPath $targetFile -PathType Leaf){$required+=(Get-Item -LiteralPath $targetFile).Length}}
  if($required-gt 4GB){throw 'Paczka Launchera przekracza limit.'};EnsureSpace $launcherRoot $required
  foreach($entry in $archive.Entries){$file=SafeChild $staging $entry.FullName;if($entry.FullName.EndsWith('/')-or $entry.FullName.EndsWith('\')){New-Item -ItemType Directory -Force $file|Out-Null;continue};New-Item -ItemType Directory -Force (Split-Path $file)|Out-Null;[IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$file,$false)}
 }finally{$archive.Dispose()}
 if(-not (Test-Path -LiteralPath (Join-Path $staging 'EpicSecure.exe'))){throw 'Brak pliku startowego Launchera.'}
 # Back up every replaced file before replacing the first file.
 foreach($file in Get-ChildItem -LiteralPath $staging -File -Recurse){$relative=$file.FullName.Substring($staging.Length).TrimStart('\');$targetFile=SafeChild $launcherRoot $relative;RejectParentLinks (Split-Path $targetFile);$exists=Test-Path -LiteralPath $targetFile -PathType Leaf;$saved=SafeChild $backup $relative;if($exists){New-Item -ItemType Directory -Force (Split-Path $saved)|Out-Null;Copy-Item -LiteralPath $targetFile -Destination $saved};$journal.Add([pscustomobject]@{relative=$relative;existed=$exists;applied=$false})}
 [IO.File]::WriteAllText((Join-Path $backup 'journal.json'),($journal|ConvertTo-Json -Depth 6))
 foreach($entry in $journal){$source=SafeChild $staging $entry.relative;$targetFile=SafeChild $launcherRoot $entry.relative;New-Item -ItemType Directory -Force (Split-Path $targetFile)|Out-Null;$entry.applied=$true;Copy-Item -LiteralPath $source -Destination $targetFile -Force}
 $success=$true;Log ('Installed '+$release.version)
 [IO.File]::WriteAllText($result,(@{success=$true;version=$release.version;backup=$backup;time=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))
}catch{
 $failure=$_.Exception.Message;Log ('FAILED: '+$failure)
 for($i=$journal.Count-1;$i-ge 0;$i--){$entry=$journal[$i];if(-not $entry.applied){continue};try{$targetFile=SafeChild $launcherRoot $entry.relative;if($entry.existed){Copy-Item -LiteralPath (SafeChild $backup $entry.relative) -Destination $targetFile -Force}else{Remove-Item -LiteralPath $targetFile -ErrorAction SilentlyContinue}}catch{Log ('Rollback error: '+$_.Exception.Message)}}
 try{[IO.File]::WriteAllText($result,(@{success=$false;error=$failure;backup=$backup;time=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json))}catch{}
}finally{
 if($staging-and (Test-Path -LiteralPath $staging)){$resolved=[IO.Path]::GetFullPath($staging);$allowed=[IO.Path]::GetFullPath((Join-Path $launcherRoot 'UpdateStaging')).TrimEnd('\')+'\';if($resolved.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)){Remove-Item -LiteralPath $resolved -Recurse -Force -ErrorAction SilentlyContinue}}
 if($Restart-and (Test-Path -LiteralPath (Join-Path $launcherRoot 'EpicSecure.exe'))){try{Start-Process -FilePath (Join-Path $launcherRoot 'EpicSecure.exe') -WorkingDirectory $launcherRoot -WindowStyle Normal}catch{Log ('Restart error: '+$_.Exception.Message)}}
}
if(-not $success){exit 1}
